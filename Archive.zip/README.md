<h1>pixi, react and redux</h1>

Download, navigate in the terminal to the directory it is in and then type in "npm start".

This can be viewed here:  http://spiralballs-env.us-east-2.elasticbeanstalk.com/

This is an exercise to have the store of redux control everything that is happening in a pixi canvas:

<img src="https://i.imgur.com/MuoeoYI.png" />

And you can edit the redux store and control the items on the stage:

<img src="https://i.imgur.com/75TbGdP.png" />